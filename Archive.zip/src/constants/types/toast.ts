export interface IToast {
  title: string;
  message: string;
}
